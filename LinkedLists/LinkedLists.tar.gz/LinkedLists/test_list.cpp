#include <iostream>
#include "Node.h"

int main()
{
    LinkedList<float> testList;
    
    testList.insertHead(34.123);
    testList.insertHead(78.343);
    testList.insertHead(12.428);
    
    testList.printList();
    
    
    /*
    Node<float> loner(3.1415);
    
    std::cout << "This is the data in the node: " << loner << std::endl;
    
    loner.setData(345.23452);
    
    std::cout << "This is the data in the node: " << loner << std::endl;
    */
    
    return 0;
}