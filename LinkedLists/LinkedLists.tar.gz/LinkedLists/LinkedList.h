/*
Linked list class. Uses the Node class to store data

*/

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include "Node.h"

template <class T>
class LinkedList {
    private:
        Node * head = nullptr;
        int length = 0;
    public:
        // Constructors
        LinkedList () {}
        LinkedList (Node * _data) { head = _data; }
        // Destructor
        ~LinkedList ();
        // Insertion methods
        void insertHead (T data);
        void insertHead (Node * new_node);
        // Delete methods
        
        // Search methods
        
        // Print methods
        void printList (); 
};

////// INSERTION METHODS //////

template <class T>
void LinkedList<T>::insertHead (T data)
{
    // Create a new node instance with the data provided
    Node * new_node = new Node(data);
    insertHead(new_node);
}

template <class T>
void LinkedList<T>::insertHead (Node * new_node)
{
    new_node->setNext(head);
    head = new_node;
}


////// PRINT METHODS //////
template <class T>
void LinkedList<T>::printList()
{
    Node * item = head;
    
    std::cout << "[ ";
    while (item != nullptr)
    {
        std::cout << item->getData() << " ";
        item = item->getNext();
    }
    std::cout << " ]" << std::endl;
}

#endif