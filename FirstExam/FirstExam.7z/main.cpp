/*
System for school grades
It uses a template Array and a Student class to keep track of student grades.

Arturo Burela A01019906
Fernando Alcántara A01019595
September 14, 2016

Partial_Evaluation_1

*/

#include "GradeSystem.h"

using namespace std;

int main()
{
    std::cout << "Welcome to the Student Grades Tracking System (SGTS)" << std::endl;
    GradeSystem main;   //Create a GradeSystem object to call the constructor of the class
	return 0;
}