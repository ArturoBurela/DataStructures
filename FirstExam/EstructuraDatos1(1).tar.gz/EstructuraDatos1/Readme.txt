Que pedo putito.

Para el programa ya están las instrucciones en blackboard, hay que organizarlo así:

Nomas un cpp para que no haya pedo y es el main, aquí importamos los .h que necesitamos y las clases las ponemos
en un solo archivo para que no haya problemas con los templates. El main es el que muestra los menús, crea los 
objetos con la información desde el StudentData.txt


System for school grades:

Write a program using the Array class seen in class to keep track of student grades. Your program will need to follow these requirements:

- Create a class 'Student'. It contains an Array of grades, and optionally an array of subject names. Each student has 6 different subjects. A student has a name, and an average grade. Add operator overloads to sort by average grade.

- Your program will use an Array of Student to keep track of data. You should store at least 5 students. You should allow the user of the system to view grades by student, grades by subject, list the students sorted by average, modify grades for a specific student and subject.

- The data for your student grades should be read from a text file. If you modify the grades in your system, you should write the changes to the file.

Upload a zip file containing all your source code and the file you use for the data. Do NOT upload project files for Visual Studio or X-Code.

Remember to write correct code that is understandable, efficient and easy to maintain. This means:

- Write comments

- Use adequate coding and naming conventions

- Keep your program simple

- Write your contact details for other programmers to find you

-Write all your code and documentation in English
